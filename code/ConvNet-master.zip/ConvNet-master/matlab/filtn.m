function c = filtn(a, b, type)

c = convn(a, flipall(b), type);

end

